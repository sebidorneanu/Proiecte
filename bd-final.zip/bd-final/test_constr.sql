-- Testare constrângeri

-- 1. Testarea constrângerii de tip PRIMARY KEY (PK)
-- Încercare de inserare a unei valori duplicate pentru o cheie primară
-- Așteptat: ORA-00001: unique constraint (schema.TABLE_PK) violated
INSERT INTO hoteluri (hotel_id, oras, adresa, numar_stele, numar_camere)
VALUES (1, 'Timișoara', 'Strada Libertății, Nr. 5', 5, 70);
-- Mesaj de eroare: ORA-00001: unique constraint (schema.HOTELURI_PK) violated

-- 2. Testarea constrângerii de tip NOT NULL (NN)
-- Încercare de inserare a unei valori NULL într-un câmp care nu acceptă NULL
-- Așteptat: ORA-01400: cannot insert NULL into (schema.TABLE.COLUMN)
INSERT INTO camere (camera_id, tip_camera, pret_pe_noapte, disponibilitate, hotel_id)
VALUES (3, NULL, 150, 'Y', 1);
-- Mesaj de eroare: ORA-01400: cannot insert NULL into (schema.CAMERE.TIP_CAMERA)

-- 3. Testarea constrângerii de tip UNIQUE (UK)
-- Încercare de inserare a unei valori duplicate într-un câmp care trebuie să fie unic
-- Așteptat: ORA-00001: unique constraint (schema.TABLE_COLUMN_UK) violated
INSERT INTO clienti (client_id, nume, prenume, email, telefon)
VALUES (3, 'Ionescu', 'Maria', 'ana.georgescu@gmail.com', '0734567890');
-- Mesaj de eroare: ORA-00001: unique constraint (schema.CLIENTI_EMAIL_UK) violated

-- 4. Testarea constrângerii de tip CHECK (CK)
-- Încercare de inserare a unei valori care nu respectă condiția CHECK
-- Așteptat: ORA-02290: check constraint (schema.CONSTRAINT_NAME) violated
INSERT INTO angajati (angajat_id, nume, prenume, functie, salariu, hotel_id)
VALUES (4, 'Vasilescu', 'Andrei', 'Electrician', 3000, 1);
-- Mesaj de eroare: ORA-02290: check constraint (schema.ANGAJATI_FUNCTIE_CK) violated

-- 5. Testarea constrângerii de tip FOREIGN KEY (FK)
-- Încercare de inserare a unei valori inexistente într-un câmp referit de o cheie externă
-- Așteptat: ORA-02291: integrity constraint (schema.CONSTRAINT_NAME) violated - parent key not found
INSERT INTO rezervari (rezervare_id, data_check_in, data_check_out, status, camera_id, client_id)
VALUES (3, TO_DATE('2025-03-01', 'YYYY-MM-DD'), TO_DATE('2025-03-10', 'YYYY-MM-DD'), 'Confirmata', 10, 1);
-- Mesaj de eroare: ORA-02291: integrity constraint (schema.CAMERE_REZERVARI_FK) violated - parent key not found

-- 6. Testarea ștergerii cu constrângeri FK
-- Încercare de ștergere a unui hotel referit de alte tabele
-- Așteptat: ORA-02292: integrity constraint (schema.CONSTRAINT_NAME) violated - child record found
DELETE FROM hoteluri WHERE hotel_id = 1;
-- Mesaj de eroare: ORA-02292: integrity constraint (schema.HOTELURI_CAMERE_FK) violated - child record found

-- 7. Testarea actualizării unui câmp referit de FK
-- Încercare de actualizare a unei chei primare referite
-- Așteptat: ORA-02292: integrity constraint (schema.CONSTRAINT_NAME) violated - child record found
UPDATE hoteluri SET hotel_id = 10 WHERE hotel_id = 1;
-- Mesaj de eroare: ORA-02292: integrity constraint (schema.HOTELURI_ANGAJATI_FK) violated - child record found

-- 8. Testarea încercării de inserare cu încălcarea CHECK pentru salariu
-- Așteptat: ORA-02290: check constraint (schema.CONSTRAINT_NAME) violated
INSERT INTO angajati (angajat_id, nume, prenume, functie, salariu, hotel_id)
VALUES (5, 'Popa', 'George', 'Manager', -1000, 2);
-- Mesaj de eroare: ORA-02290: check constraint (schema.ANGAJATI_SALARIU_CK) violated

-- Sfârșitul scriptului
COMMIT;
