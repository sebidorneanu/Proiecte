-- Use-case: Creare rezervare
-- Descriere: Se verifică disponibilitatea camerei, se creează rezervarea și se actualizează starea camerei.
DECLARE
    v_disponibilitate CHAR(1);
BEGIN
    -- Verificăm disponibilitatea camerei
    SELECT disponibilitate
    INTO v_disponibilitate
    FROM camere
    WHERE camera_id = 1; -- ID-ul camerei alese

    IF v_disponibilitate = 'Y' THEN
        -- Începem tranzacția
        SAVEPOINT rezervare_start;

        -- Creăm rezervarea
        INSERT INTO rezervari (rezervare_id, data_check_in, data_check_out, status, camera_id, client_id)
        VALUES (NULL, TO_DATE('2025-01-10', 'YYYY-MM-DD'), TO_DATE('2025-01-15', 'YYYY-MM-DD'), 'Confirmata', 1, 1);

        -- Actualizăm disponibilitatea camerei
        UPDATE camere
        SET disponibilitate = 'N'
        WHERE camera_id = 1;

        -- Confirmăm tranzacția
        COMMIT;
    ELSE
        ROLLBACK TO rezervare_start;
        DBMS_OUTPUT.PUT_LINE('Rezervarea nu poate fi realizată: Camera nu este disponibilă.');
    END IF;
END;
/
