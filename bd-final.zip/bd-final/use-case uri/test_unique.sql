BEGIN
    INSERT INTO clienti (client_id, nume, prenume, email, telefon)
    VALUES (NULL, 'Popescu', 'Ion', 'george.ionescu@gmail.com', '0712345678');
    
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Clientul a fost adăugat cu succes.');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Eroare: Emailul este deja înregistrat.');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Eroare necunoscută: ' || SQLERRM);
END;
/

