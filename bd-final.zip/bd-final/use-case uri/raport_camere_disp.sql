-- Use-case: Raport camere disponibile
DECLARE
    cursor camere_cursor IS
        SELECT camera_id, tip_camera, pret_pe_noapte
        FROM camere
        WHERE disponibilitate = 'Y';
BEGIN
    FOR camera_rec IN camere_cursor LOOP
        DBMS_OUTPUT.PUT_LINE('Camera ID: ' || camera_rec.camera_id || ', Tip: ' || camera_rec.tip_camera || ', Pret: ' || camera_rec.pret_pe_noapte);
    END LOOP;
END;
/
