-- Use-case: Adăugare serviciu la rezervare
-- Descriere: Se adaugă un serviciu specific la rezervare, cu verificarea cantității și a angajatului.
BEGIN
    -- Adăugăm serviciul la rezervare
    INSERT INTO rezervariservicii (rezervare_serviciu_id, cantitate, data_serviciu, rezervare_id, serviciu_id, angajat_id)
    VALUES (NULL, 2, SYSDATE, 1, 1, 1);

    -- Confirmăm tranzacția
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Serviciul a fost adăugat cu succes la rezervare.');
END;
/
