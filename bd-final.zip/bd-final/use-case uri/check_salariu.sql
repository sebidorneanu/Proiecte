-- Use-case: Testare constrângere CHECK pe salariu
-- Descriere: Se verifică constrângerea CHECK care interzice valori negative pentru salariu.
BEGIN
    INSERT INTO angajati (angajat_id, nume, prenume, functie, salariu, hotel_id)
    VALUES (NULL, 'Ionescu', 'Maria', 'Manager', -5000, 1);

    -- Confirmăm tranzacția
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Angajatul a fost adăugat cu succes.');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Eroare: Salariul nu poate fi negativ.');
END;
/
