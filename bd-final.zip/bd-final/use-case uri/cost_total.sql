-- Use-case: Calcul cost total rezervare
-- Descriere: Se calculează costul total al unei rezervări (cost cameră + cost servicii).
DECLARE
    v_pret_total NUMBER(10, 2) := 0;
    v_pret_camera NUMBER(10, 2);
    v_pret_servicii NUMBER(10, 2);
BEGIN
    -- Calculăm costul camerei (număr de nopți * preț pe noapte)
    SELECT (TO_DATE('2025-01-15', 'YYYY-MM-DD') - TO_DATE('2025-01-10', 'YYYY-MM-DD')) * pret_pe_noapte
    INTO v_pret_camera
    FROM camere
    WHERE camera_id = 1;

    -- Calculăm costul serviciilor asociate rezervării
    SELECT SUM(rs.cantitate * s.pret_unitate)
    INTO v_pret_servicii
    FROM rezervariservicii rs
    JOIN servicii s ON rs.serviciu_id = s.serviciu_id
    WHERE rs.rezervare_id = 1;

    -- Calculăm costul total
    v_pret_total := v_pret_camera + NVL(v_pret_servicii, 0);

    DBMS_OUTPUT.PUT_LINE('Costul total al rezervării este: ' || v_pret_total || ' lei.');
END;
/
