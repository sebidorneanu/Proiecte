-- Use-case: Anulare rezervare
-- Descriere: Anulăm rezervarea și actualizăm disponibilitatea camerei.
DECLARE
    v_camera_id NUMBER(3);
BEGIN
    -- Găsim camera asociată rezervării
    SELECT camera_id
    INTO v_camera_id
    FROM rezervari
    WHERE rezervare_id = 1;

    -- Anulăm rezervarea
    UPDATE rezervari
    SET status = 'Anulata'
    WHERE rezervare_id = 1;

    -- Actualizăm disponibilitatea camerei
    UPDATE camere
    SET disponibilitate = 'Y'
    WHERE camera_id = v_camera_id;

    -- Confirmăm tranzacția
    COMMIT;

    DBMS_OUTPUT.PUT_LINE('Rezervarea a fost anulată, iar camera este acum disponibilă.');
END;
/
