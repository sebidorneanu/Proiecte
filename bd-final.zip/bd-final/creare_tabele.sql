CREATE TABLE angajati (
    angajat_id NUMBER(3) NOT NULL,
    nume       VARCHAR2(100) NOT NULL,
    prenume    VARCHAR2(100) NOT NULL,
    functie    VARCHAR2(50) NOT NULL,
    salariu    NUMBER(10, 2) NOT NULL,
    hotel_id   NUMBER(2) NOT NULL
);

ALTER TABLE angajati
    ADD CONSTRAINT angajati_functie_ck
        CHECK ( functie IN ( 'Camerista', 'Manager', 'Receptioner' ) );

ALTER TABLE angajati ADD CHECK ( salariu > 0 );

ALTER TABLE angajati ADD CONSTRAINT angajati_pk PRIMARY KEY ( angajat_id );

CREATE TABLE camere (
    camera_id       NUMBER(3) NOT NULL,
    tip_camera      VARCHAR2(30) NOT NULL,
    pret_pe_noapte  NUMBER(10, 2) NOT NULL,
    disponibilitate CHAR(1) NOT NULL,
    hotel_id        NUMBER(2) NOT NULL
);

ALTER TABLE camere
    ADD CONSTRAINT tip_camera_ck CHECK ( tip_camera IN ( 'Double', 'Single' ) );

ALTER TABLE camere ADD CHECK ( pret_pe_noapte > 0 );

ALTER TABLE camere ADD CONSTRAINT camere_pk PRIMARY KEY ( camera_id );

CREATE TABLE clienti (
    client_id NUMBER(3) NOT NULL,
    nume      VARCHAR2(100) NOT NULL,
    prenume   VARCHAR2(100) NOT NULL,
    email     VARCHAR2(100) NOT NULL,
    telefon   VARCHAR2(15) NOT NULL
);

ALTER TABLE clienti
    ADD CONSTRAINT clienti_email_ck CHECK ( REGEXP_LIKE ( email,
                                                          '[a-z0-9._%-]+@[a-z0-9._%-]+\.[a-z]{2,4}' ) );

ALTER TABLE clienti ADD CONSTRAINT clienti_pk PRIMARY KEY ( client_id );

ALTER TABLE clienti ADD CONSTRAINT clienti_email_uk UNIQUE ( email );

CREATE TABLE hoteluri (
    hotel_id     NUMBER(2) NOT NULL,
    oras         VARCHAR2(25) NOT NULL,
    adresa       VARCHAR2(50) NOT NULL,
    numar_stele  NUMBER(1) NOT NULL,
    numar_camere NUMBER(3) NOT NULL
);

ALTER TABLE hoteluri ADD CHECK ( numar_camere > 0 );

ALTER TABLE hoteluri ADD CONSTRAINT hoteluri_pk PRIMARY KEY ( hotel_id );

CREATE TABLE manageri (
    manager_id NUMBER(2) NOT NULL,
    nume       VARCHAR2(100) NOT NULL,
    prenume    VARCHAR2(100) NOT NULL,
    email      VARCHAR2(100) NOT NULL,
    hotel_id   NUMBER(2) NOT NULL
);

ALTER TABLE manageri ADD CONSTRAINT manageri_pk PRIMARY KEY ( manager_id );

ALTER TABLE manageri ADD CONSTRAINT key_2 UNIQUE ( hotel_id );

CREATE TABLE rezervari (
    rezervare_id   NUMBER(3) NOT NULL,
    data_check_in  DATE NOT NULL,
    data_check_out DATE NOT NULL,
    status         VARCHAR2(50) NOT NULL,
    camera_id      NUMBER(3) NOT NULL,
    client_id      NUMBER(3) NOT NULL
);

ALTER TABLE rezervari
    ADD CONSTRAINT rezervari_status_ck CHECK ( status IN ( 'Anulata', 'Confirmata' ) );

ALTER TABLE rezervari ADD CONSTRAINT rezervari_pk PRIMARY KEY ( rezervare_id );

CREATE TABLE rezervariservicii (
    rezervare_serviciu_id NUMBER(2) NOT NULL,
    cantitate             NUMBER(3) NOT NULL,
    data_serviciu         DATE NOT NULL,
    rezervare_id          NUMBER(3) NOT NULL,
    serviciu_id           NUMBER(3) NOT NULL,
    angajat_id            NUMBER(3) NOT NULL
);

ALTER TABLE rezervariservicii ADD CONSTRAINT rezervariservicii_pk PRIMARY KEY ( rezervare_serviciu_id,
                                                                                serviciu_id );

CREATE TABLE servicii (
    serviciu_id  NUMBER(3) NOT NULL,
    denumire     VARCHAR2(100) NOT NULL,
    pret_unitate NUMBER(10, 2) NOT NULL
);

ALTER TABLE servicii ADD CONSTRAINT servicii_pret_unitate_ck CHECK ( pret_unitate > 0 );

ALTER TABLE servicii ADD CONSTRAINT servicii_pk PRIMARY KEY ( serviciu_id );

ALTER TABLE servicii ADD CONSTRAINT servicii_denumire_uk UNIQUE ( denumire );

ALTER TABLE rezervariservicii
    ADD CONSTRAINT angajati_rezervariservicii_fk FOREIGN KEY ( angajat_id )
        REFERENCES angajati ( angajat_id );

ALTER TABLE rezervari
    ADD CONSTRAINT camere_rezervari_fk FOREIGN KEY ( camera_id )
        REFERENCES camere ( camera_id );

ALTER TABLE rezervari
    ADD CONSTRAINT clienti_rezervari_fk FOREIGN KEY ( client_id )
        REFERENCES clienti ( client_id );

ALTER TABLE angajati
    ADD CONSTRAINT hoteluri_angajati_fk FOREIGN KEY ( hotel_id )
        REFERENCES hoteluri ( hotel_id );

ALTER TABLE camere
    ADD CONSTRAINT hoteluri_camere_fk FOREIGN KEY ( hotel_id )
        REFERENCES hoteluri ( hotel_id );

ALTER TABLE manageri
    ADD CONSTRAINT hoteluri_manageri_fk1 FOREIGN KEY ( hotel_id )
        REFERENCES hoteluri ( hotel_id );

ALTER TABLE rezervariservicii
    ADD CONSTRAINT rezervari_rezervariservicii_fk FOREIGN KEY ( rezervare_id )
        REFERENCES rezervari ( rezervare_id );

ALTER TABLE rezervariservicii
    ADD CONSTRAINT servicii_rezervariservicii_fk FOREIGN KEY ( serviciu_id )
        REFERENCES servicii ( serviciu_id );

-- Creare secvențe pentru autoincrement
CREATE SEQUENCE seq_angajati_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_camere_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_clienti_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_hoteluri_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_manageri_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_rezervari_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_rezervariservicii_id START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE seq_servicii_id START WITH 1 INCREMENT BY 1;

-- Trigger pentru tabelul angajati
CREATE OR REPLACE TRIGGER trg_angajati_id
BEFORE INSERT ON angajati
FOR EACH ROW
BEGIN
    IF :NEW.angajat_id IS NULL THEN
        SELECT seq_angajati_id.NEXTVAL INTO :NEW.angajat_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul camere
CREATE OR REPLACE TRIGGER trg_camere_id
BEFORE INSERT ON camere
FOR EACH ROW
BEGIN
    IF :NEW.camera_id IS NULL THEN
        SELECT seq_camere_id.NEXTVAL INTO :NEW.camera_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul clienti
CREATE OR REPLACE TRIGGER trg_clienti_id
BEFORE INSERT ON clienti
FOR EACH ROW
BEGIN
    IF :NEW.client_id IS NULL THEN
        SELECT seq_clienti_id.NEXTVAL INTO :NEW.client_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul hoteluri
CREATE OR REPLACE TRIGGER trg_hoteluri_id
BEFORE INSERT ON hoteluri
FOR EACH ROW
BEGIN
    IF :NEW.hotel_id IS NULL THEN
        SELECT seq_hoteluri_id.NEXTVAL INTO :NEW.hotel_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul manageri
CREATE OR REPLACE TRIGGER trg_manageri_id
BEFORE INSERT ON manageri
FOR EACH ROW
BEGIN
    IF :NEW.manager_id IS NULL THEN
        SELECT seq_manageri_id.NEXTVAL INTO :NEW.manager_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul rezervari
CREATE OR REPLACE TRIGGER trg_rezervari_id
BEFORE INSERT ON rezervari
FOR EACH ROW
BEGIN
    IF :NEW.rezervare_id IS NULL THEN
        SELECT seq_rezervari_id.NEXTVAL INTO :NEW.rezervare_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul rezervariservicii
CREATE OR REPLACE TRIGGER trg_rezervariservicii_id
BEFORE INSERT ON rezervariservicii
FOR EACH ROW
BEGIN
    IF :NEW.rezervare_serviciu_id IS NULL THEN
        SELECT seq_rezervariservicii_id.NEXTVAL INTO :NEW.rezervare_serviciu_id FROM DUAL;
    END IF;
END;
/

-- Trigger pentru tabelul servicii
CREATE OR REPLACE TRIGGER trg_servicii_id
BEFORE INSERT ON servicii
FOR EACH ROW
BEGIN
    IF :NEW.serviciu_id IS NULL THEN
        SELECT seq_servicii_id.NEXTVAL INTO :NEW.serviciu_id FROM DUAL;
    END IF;
END;
/



