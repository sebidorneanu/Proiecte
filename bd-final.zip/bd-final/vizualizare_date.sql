-- 1. Vizualizare: Lista camerelor disponibile din fiecare hotel (fără afișarea cheilor primare)
SELECT 
    h.oras AS Oras_Hotel,
    h.adresa AS Adresa_Hotel,
    c.tip_camera AS Tip_Camera,
    c.pret_pe_noapte AS Pret_Noapte
FROM 
    hoteluri h
JOIN 
    camere c ON h.hotel_id = c.hotel_id
WHERE 
    c.disponibilitate = 'Y';
-- Cerință: Afisarea camerelor disponibile din fiecare hotel, excluzând cheile primare.

-- 2. Vizualizare: Lista rezervărilor, cu detalii despre client și cameră
SELECT 
    cl.nume || ' ' || cl.prenume AS Client,
    cl.email AS Email_Client,
    c.tip_camera AS Tip_Camera,
    c.pret_pe_noapte AS Pret_Noapte,
    r.data_check_in AS Check_In,
    r.data_check_out AS Check_Out,
    r.status AS Status_Rezervare
FROM 
    rezervari r
JOIN 
    clienti cl ON r.client_id = cl.client_id
JOIN 
    camere c ON r.camera_id = c.camera_id;
-- Cerință: Vizualizarea rezervărilor, cu informații relevante despre client și cameră.

-- 3. Vizualizare: Servicii prestate pentru fiecare rezervare, incluzând angajatul care a efectuat serviciul
SELECT 
    rs.data_serviciu AS Data_Serviciu,
    s.denumire AS Serviciu,
    s.pret_unitate AS Pret_Serviciu,
    a.nume || ' ' || a.prenume AS Angajat,
    r.data_check_in || ' - ' || r.data_check_out AS Perioada_Rezervare
FROM 
    rezervariservicii rs
JOIN 
    servicii s ON rs.serviciu_id = s.serviciu_id
JOIN 
    angajati a ON rs.angajat_id = a.angajat_id
JOIN 
    rezervari r ON rs.rezervare_id = r.rezervare_id;
-- Cerință: Vizualizarea serviciilor prestate pentru fiecare rezervare, incluzând numele angajatului.

-- 4. Vizualizare: Hoteluri cu numărul de camere disponibile
SELECT 
    h.oras AS Oras_Hotel,
    h.adresa AS Adresa_Hotel,
    COUNT(c.camera_id) AS Nr_Camere_Disponibile
FROM 
    hoteluri h
JOIN 
    camere c ON h.hotel_id = c.hotel_id
WHERE 
    c.disponibilitate = 'Y'
GROUP BY 
    h.oras, h.adresa;
-- Cerință: Listarea hotelurilor cu numărul de camere disponibile.
