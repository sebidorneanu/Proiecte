-- Inserarea în tabelul hoteluri
INSERT INTO hoteluri (oras, adresa, numar_stele, numar_camere)
VALUES ('București', 'Strada Unirii, Nr. 10', 4, 100);
INSERT INTO hoteluri (oras, adresa, numar_stele, numar_camere)
VALUES ('Cluj-Napoca', 'Strada Memorandumului, Nr. 3', 5, 80);
INSERT INTO hoteluri (oras, adresa, numar_stele, numar_camere)
VALUES ('Timișoara', 'Strada Libertății, Nr. 5', 3, 50);
INSERT INTO hoteluri (oras, adresa, numar_stele, numar_camere)
VALUES ('Iași', 'Strada Lăpușneanu, Nr. 7', 4, 60);
INSERT INTO hoteluri (oras, adresa, numar_stele, numar_camere)
VALUES ('Brașov', 'Bulevardul Eroilor, Nr. 12', 4, 70);

-- Inserarea în tabelul angajati
INSERT INTO angajati (nume, prenume, functie, salariu, hotel_id)
VALUES ('Popescu', 'Ion', 'Manager', 5000, 1);
INSERT INTO angajati (nume, prenume, functie, salariu, hotel_id)
VALUES ('Ionescu', 'Maria', 'Receptioner', 3000, 2);
INSERT INTO angajati (nume, prenume, functie, salariu, hotel_id)
VALUES ('Georgescu', 'Ana', 'Camerista', 2500, 3);
INSERT INTO angajati (nume, prenume, functie, salariu, hotel_id)
VALUES ('Vasilescu', 'Andrei', 'Receptioner', 3200, 4);
INSERT INTO angajati (nume, prenume, functie, salariu, hotel_id)
VALUES ('Dumitru', 'Elena', 'Manager', 5500, 5);

-- Inserarea în tabelul camere
INSERT INTO camere (tip_camera, pret_pe_noapte, disponibilitate, hotel_id)
VALUES ('Single', 150, 'Y', 1);
INSERT INTO camere (tip_camera, pret_pe_noapte, disponibilitate, hotel_id)
VALUES ('Double', 250, 'Y', 1);
INSERT INTO camere (tip_camera, pret_pe_noapte, disponibilitate, hotel_id)
VALUES ('Double', 270, 'Y', 2);
INSERT INTO camere (tip_camera, pret_pe_noapte, disponibilitate, hotel_id)
VALUES ('Single', 200, 'N', 3);
INSERT INTO camere (tip_camera, pret_pe_noapte, disponibilitate, hotel_id)
VALUES ('Single', 180, 'Y', 4);

-- Inserarea în tabelul clienti
INSERT INTO clienti (nume, prenume, email, telefon)
VALUES ('Popescu', 'Ana', 'ana.popescu@gmail.com', '0741123456');
INSERT INTO clienti (nume, prenume, email, telefon)
VALUES ('Ionescu', 'George', 'george.ionescu@gmail.com', '0742123456');
INSERT INTO clienti (nume, prenume, email, telefon)
VALUES ('Vasilescu', 'Maria', 'maria.vasilescu@gmail.com', '0743123456');
INSERT INTO clienti (nume, prenume, email, telefon)
VALUES ('Dumitru', 'Andrei', 'andrei.dumitru@gmail.com', '0744123456');
INSERT INTO clienti (nume, prenume, email, telefon)
VALUES ('Enache', 'Elena', 'elena.enache@gmail.com', '0745123456');

-- Inserarea în tabelul servicii
INSERT INTO servicii (denumire, pret_unitate)
VALUES ('Mic dejun', 50);
INSERT INTO servicii (denumire, pret_unitate)
VALUES ('Prânz', 100);
INSERT INTO servicii (denumire, pret_unitate)
VALUES ('Cina', 120);
INSERT INTO servicii (denumire, pret_unitate)
VALUES ('Spălătorie', 30);
INSERT INTO servicii (denumire, pret_unitate)
VALUES ('Masaj', 200);

-- Inserarea în tabelul rezervari
INSERT INTO rezervari (data_check_in, data_check_out, status, camera_id, client_id)
VALUES (TO_DATE('2025-01-10', 'YYYY-MM-DD'), TO_DATE('2025-01-15', 'YYYY-MM-DD'), 'Confirmata', 1, 1);
INSERT INTO rezervari (data_check_in, data_check_out, status, camera_id, client_id)
VALUES (TO_DATE('2025-01-12', 'YYYY-MM-DD'), TO_DATE('2025-01-18', 'YYYY-MM-DD'), 'Anulata', 2, 2);
INSERT INTO rezervari (data_check_in, data_check_out, status, camera_id, client_id)
VALUES (TO_DATE('2025-01-15', 'YYYY-MM-DD'), TO_DATE('2025-01-20', 'YYYY-MM-DD'), 'Confirmata', 3, 3);
INSERT INTO rezervari (data_check_in, data_check_out, status, camera_id, client_id)
VALUES (TO_DATE('2025-01-17', 'YYYY-MM-DD'), TO_DATE('2025-01-25', 'YYYY-MM-DD'), 'Confirmata', 4, 4);
INSERT INTO rezervari (data_check_in, data_check_out, status, camera_id, client_id)
VALUES (TO_DATE('2025-01-22', 'YYYY-MM-DD'), TO_DATE('2025-01-30', 'YYYY-MM-DD'), 'Anulata', 5, 5);


-- Inserări în tabelul rezervariservicii
INSERT INTO rezervariservicii (cantitate, data_serviciu, rezervare_id, serviciu_id, angajat_id)
VALUES (2, TO_DATE('2025-01-11', 'YYYY-MM-DD'), 1, 1, 1); -- Mic dejun, angajat Popescu Ion
INSERT INTO rezervariservicii (cantitate, data_serviciu, rezervare_id, serviciu_id, angajat_id)
VALUES (1, TO_DATE('2025-01-13', 'YYYY-MM-DD'), 1, 5, 3); -- Masaj, angajat Georgescu Ana
INSERT INTO rezervariservicii (cantitate, data_serviciu, rezervare_id, serviciu_id, angajat_id)
VALUES (3, TO_DATE('2025-01-16', 'YYYY-MM-DD'), 3, 2, 2); -- Prânz, angajat Ionescu Maria
INSERT INTO rezervariservicii (cantitate, data_serviciu, rezervare_id, serviciu_id, angajat_id)
VALUES (1, TO_DATE('2025-01-18', 'YYYY-MM-DD'), 4, 4, 4); -- Spălătorie, angajat Vasilescu Andrei
INSERT INTO rezervariservicii (cantitate, data_serviciu, rezervare_id, serviciu_id, angajat_id)
VALUES (2, TO_DATE('2025-01-24', 'YYYY-MM-DD'), 5, 3, 5); -- Cină, angajat Dumitru Elena


