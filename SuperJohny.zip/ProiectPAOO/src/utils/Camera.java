package utils;

public class Camera {
    public static int xCamera = 0;
    public static boolean moveRight = false;
    public static boolean moveLeft = false;

    /*public static void update(){
        if(moveLeft)
            xCamera -= 1;

        if(moveRight)
            xCamera += 1;
    }*/

    public static int getXOffset() {
        return xCamera;
    }

    public static void update(int newPos) {
            xCamera += newPos;
        //System.err.println(xCamera);
    }

}
