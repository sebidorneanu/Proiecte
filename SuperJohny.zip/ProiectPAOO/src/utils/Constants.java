package utils;

public class Constants {
    public static class PLayerConstants{

        public static final int IDLE = 0;//stat pe loc
        public static final int WALK = 1;
        public static final int RUN = 3;

        public static final int JUMP = 5;
        public static int GetSpriteAmount(int player_action)
        {
             switch(player_action)
             {
                 case IDLE:
                 case WALK:
                 case RUN:
                 case JUMP:
                 default:
                     return -1;
             }
        }
    }
    public static class Directions {
        public static final int LEFT = 0;
        public static final int UP = 1;
        public static final int RIGHT = 2;
        public static final int DOWN = 3;

    }
}
