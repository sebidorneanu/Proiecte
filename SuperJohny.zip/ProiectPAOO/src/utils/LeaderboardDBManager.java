package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LeaderboardDBManager {
    private static final String DB_URL = "jdbc:sqlite:res/db/leaderboard.db";
    private Connection connection;

    public LeaderboardDBManager() {
        createNewTable();
    }

    // Create a connection to the database
    private Connection connect() {
        if (this.connection != null) {
            return this.connection;
        }

        try {
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection(DB_URL);
        } catch (SQLException e) {
            System.out.println("Connection to SQLite has failed: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        return this.connection;
    }

    // Create a new table if it does not exist
    private void createNewTable() {
        String sql = "CREATE TABLE IF NOT EXISTS leaderboard (\n"
                + "    PlayerName TEXT NOT NULL,\n"
                + "    Time INTEGER NOT NULL\n"
                + ");";

        try (Statement stmt = this.connect().createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Insert a new player and their time
    public void insert(String playerName, int time) {
        String sql = "INSERT INTO leaderboard(PlayerName, Time) VALUES(?, ?)";

        try (PreparedStatement pstmt = this.connect().prepareStatement(sql)) {
            pstmt.setString(1, playerName);
            pstmt.setInt(2, time);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Delete a player by name
    public void delete(String playerName) {
        String sql = "DELETE FROM leaderboard WHERE PlayerName = ?";

        try (PreparedStatement pstmt = this.connect().prepareStatement(sql)) {
            pstmt.setString(1, playerName);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Retrieve the leaderboard data
    public void selectAll() {
        String sql = "SELECT PlayerName, Time FROM leaderboard";

        try (Statement stmt = this.connect().createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(rs.getString("PlayerName") + "\t" + rs.getInt("Time"));
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Update a player's time by name
    public void update(String playerName, int newTime) {
        String sql = "UPDATE leaderboard SET Time = ? WHERE PlayerName = ?";

        try (PreparedStatement pstmt = this.connect().prepareStatement(sql)) {
            pstmt.setInt(1, newTime);
            pstmt.setString(2, playerName);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // Close the database connection
    public void close() {
        try {
            if (this.connection != null && !this.connection.isClosed()) {
                this.connection.close();
                System.out.println("Connection to SQLite has been closed.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}
