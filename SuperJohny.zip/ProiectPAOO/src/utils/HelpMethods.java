package utils;
import PaooGame.Game;
import PaooGame.Tiles.*;

import javax.xml.crypto.dsig.keyinfo.X509IssuerSerial;

import java.awt.*;
import java.awt.geom.Rectangle2D;

import static PaooGame.Tiles.Tile.*;

public class HelpMethods {
    public static boolean CanMoveHere(float x, float y, int[][] lvlData) {
        Boolean canMove = true;
        // test sa ramanem pe mapa, -32 pentru ca e player tile width
        if(!(x >= 0 && x <= 2080)) {
            //System.err.println("OUT OF BOUNDS");
            return false;
        }
        //System.err.println(IsSolid(x + 32, y + 32, lvlData));
       if(IsSolid(x,y,lvlData)) {// || IsSolid(x + 32, y + 32, lvlData) || IsSolid(x + 32, y, lvlData) ||
               //IsSolid(x, y + 32, lvlData)) {
           //System.err.println("CANNOT MOVE AT (" + x + ", " + y + "), TILE SOLID");
           canMove = false;
        }
        return canMove;
    }


    private static boolean IsSolid(float x, float y, int[][] levelData)
    {
        //int maxWidth = levelData[0].length * TILE_SIZE;

        //redundant, am testat deja
        /*
        if(x < 0 || x >= maxWidth)
            return true;

        if(y < 0 || y >= Game.GAME_HEIGHT)
            return true;
         */

        int xIndex = (int)(Math.abs(x) / TILE_SIZE);
        int yIndex = (int)(Math.abs(y) / TILE_SIZE);

        //System.out.println("x: " + x + " y: " + y + " "  + xIndex + " " + yIndex);
        if(xIndex < 0 || xIndex >= 130 || yIndex < 0 || yIndex >= 15)
            return false;
        int value = levelData[yIndex][xIndex];
        //System.err.println(value);

        if(value == 42) {
            Game.getPlayer().setHasTouchedGreenCannon();
        } else if (value == 9) {
            Game.getPlayer().setHasTouchedBrownCannon();
        }

        if (value == -1) return false;
        else if (tiles[value] != null) return tiles[value].IsSolid();
            else return false;
    }



    public static float GetEntityXPosNextToWall(Rectangle2D.Float hitbox, float xSpeed)
    {
        int currentTile = (int) (hitbox.x/TILE_SIZE);
        if(xSpeed > 0 )
        {
            //Right
            int tileXPos = currentTile * TILE_SIZE;
            int xOffset = (int) (TILE_SIZE - hitbox.width);
            return tileXPos + xOffset - 1;
        }
        else {
            //Left
            return currentTile*TILE_SIZE;
        }
    }

    public static float GetEntityYPosUnderRoofFloor(Rectangle2D.Float hitbox, float airSpeed)
    {
        int currentTile = (int) (hitbox.y/TILE_SIZE);

        if(airSpeed > 0) {
            int tileYPos = currentTile * TILE_SIZE;
            int yOffset = (int) (TILE_SIZE - hitbox.height);
            return tileYPos + yOffset - 1;
        }else{
            //Jumping
            return currentTile*TILE_SIZE;
        }
    }

    public static boolean IsEntityOnFloor(Rectangle2D.Float hitbox, int[][] levelData)
    {
        return IsSolid(hitbox.x, hitbox.y + hitbox.height + 5, levelData);
        /*if(IsSolid(hitbox.x,hitbox.y+hitbox.height+1,levelData))
            if(IsSolid(hitbox.x + hitbox.width, hitbox.y + hitbox.height+1, levelData))
                return true;
        return false;*/
    }
}
