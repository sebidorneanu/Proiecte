package utils;

import java.sql.*;
import PaooGame.Game;

import javax.swing.*;

public class SaveGameDBManager {
    private static final String DB_URL = "jdbc:sqlite:savegame.db";

    private Game gamepanel;
    private Connection connection;

    public SaveGameDBManager(Game game) {
        this.gamepanel = game;
        connect();
        createTable();
    }

    private void connect() {
        try {
            Class.forName("org.sqlite.JDBC");
            this.connection = DriverManager.getConnection(DB_URL);
        } catch (SQLException e) {
            System.out.println("Connection to SQLite has failed: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS savegame (\n"
                + " id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
                + " playerx REAL,\n"
                + " playery REAL,\n"
                + " lives INTEGER,\n"
                + " time INTEGER,\n"
                + " levelid INTEGER\n"
                + ");";

        try (Statement stmt = connection.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void saveGame(float playerX, float playerY, int lives, int time, int levelId) {
        String sql = "INSERT INTO savegame(playerx, playery, lives, time, levelid) VALUES(?,?,?,?,?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setFloat(1, playerX);
            pstmt.setFloat(2, playerY);
            pstmt.setInt(3, lives);
            pstmt.setInt(4, time);
            pstmt.setInt(5, levelId);
            pstmt.executeUpdate();
            System.out.println("Game saved successfully!");
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                int saveGameId = rs.getInt(1);
                System.out.println("Game saved successfully! Save Game ID: " + saveGameId);
                JOptionPane.showMessageDialog(null, "Game saved successfully.\nSave Game ID: " + saveGameId, "Game Saved", JOptionPane.INFORMATION_MESSAGE);
            } else {
                System.out.println("Game saved successfully! (No Save Game ID retrieved)");
                JOptionPane.showMessageDialog(null, "Game saved successfully.", "Game Saved", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void loadGame(int saveId) {
        String sql = "SELECT playerx, playery, lives, time, levelid FROM savegame WHERE id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, saveId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                float playerX = rs.getFloat("playerx");
                float playerY = rs.getFloat("playery");
                int lives = rs.getInt("lives");
                int time = rs.getInt("time");
                int levelId = rs.getInt("levelid");

                // You can now use these values to set the game state
                System.out.println("Game loaded successfully!");
                System.out.println("Player X: " + playerX);
                System.out.println("Player Y: " + playerY);
                System.out.println("Lives: " + lives);
                System.out.println("Time: " + time);
                System.out.println("Level ID: " + levelId);

                  gamepanel.getPlayer().setPlayerPosition(playerX, playerY);
                  gamepanel.getPlayer().setLives(lives);
                  gamepanel.getTimer().setTimeInSeconds(time);
                  gamepanel.levelManager.selectLevel(levelId);
                // e.g., game.setLives(lives);
                // e.g., game.setTime(time);
                // e.g., game.setLevelId(levelId);
            } else {
                System.out.println("No save game found with the given ID.");
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void close() {
        try {
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
