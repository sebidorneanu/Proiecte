package entities;

import PaooGame.Game;
import utils.Camera;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

import static PaooGame.Tiles.LevelConstructor.map;
import static utils.Constants.PLayerConstants.*;
import static PaooGame.Graphics.Assets.player_right;
import static utils.HelpMethods.*;

public class Player extends Entity {
    private BufferedImage[] current_animation;
    private boolean moving = false;
    private int aniIndex, aniTick, aniSpeed = 5;
    private int playerAction = IDLE;
    private boolean left, up, right, down, speed, jump;
    private float playerSpeed = 1.0f;
    private int[][] levelData;
    private float xDrawOffset = 0;
    private float yDrawOffset = 0;

    private int lives;

    private float airSpeed = 0f;
    private float gravity = 1f;
    private float jumpSpeed = -4f;
    private float fallSpeedAfterCollision = 1f;
    private boolean inAir = false;

    private boolean hasTouchedGreenCannon = false;
    private boolean hasTouchedBrownCannon = false;

    public Player(float x, float y, int width, int height) {
        super(x, y, width, height);
        initHitbox(x, y, 28, 28);
        initAnimations();
        loadLvlData();
        lives = 3;
    }

    public void update() {
        //System.out.println(inAir);
        updatePos();
        updateHitbox();
        updateAnimation();
        setAnimation();

        if(hasTouchedGreenCannon) {
            Game.levelManager.selectLevel(1);
            resetPlayer();
            hasTouchedGreenCannon = false;
        }

        if(hasTouchedBrownCannon) {
            lives--;
            updateXPos(6); //lansam jucatorul in fata
            hitBox.y = 4;
            y = 4;
            hasTouchedBrownCannon = false;
            onPlayerLifeLoss();
        }

        if(HasReachedLevelEnd() && Game.levelManager.getCurrentLevel() <= 2) {
            System.err.println("LEVEL END");
            //g.drawString("LEVEL COMPLETE!!!", 340, 280);
            Game.levelManager.selectLevel(Game.levelManager.getCurrentLevel() + 1);
            resetPlayer();
            //Game.levelTimer.resetTimer();
        }
        else if (HasReachedLevelEnd() && Game.levelManager.getCurrentLevel() == 3) {
            displayCompletionDialog();
            int result = JOptionPane.showConfirmDialog(null, "Would you like to play again?", "Game Won", JOptionPane.YES_NO_OPTION);
            if(result == 0) {
                resetPlayer();
                lives = 3;
                Game.levelTimer.resetTimer();
                Game.levelManager.selectLevel(1);
            }
        }
        if(hitBox.y > 300) {
            // player fell through the map
            resetPlayer();
            System.err.println(x + " " + y);
            lives--;
            onPlayerLifeLoss();
            System.err.println(lives);
        }
    }

    private void onPlayerLifeLoss() {
        if(lives == -1) {
            int result = JOptionPane.showConfirmDialog(null, "Would you like to retry?", "Game Over", JOptionPane.YES_NO_OPTION);
            if(result == 0) {
                resetPlayer();
                lives = 3;
                Game.levelTimer.resetTimer();
            }
            else {
                JOptionPane.showMessageDialog(null, "Game over. Start from the beginning.", "Game over", JOptionPane.INFORMATION_MESSAGE);
                lives = 3;
                Game.levelTimer.resetTimer();
            }
            Game.levelManager.selectLevel(1);
        }
    }

    public void render(Graphics g) {
        int renderX = (int) (hitBox.x - Camera.getXOffset());
        int renderY = (int) (hitBox.y - yDrawOffset);

        g.drawImage(current_animation[aniIndex], renderX, renderY, width, height, null);
        g.drawString("Lives: " + lives, 20, 20);
        drawHitbox(g);
    }

    public void resetPlayer() {
        this.x = 0;
        this.y = 120;
        hitBox.x = 0;
        hitBox.y = 120;
        Camera.xCamera = 0;
    }

    public void setPlayerPosition(float x, float y) {
        this.x = x;
        this.y = y;
        hitBox.x = x;
        hitBox.y = y;
        int middleX = 800 / 2 - 32; // Assuming a screen width of 800 pixels
        if(x < middleX) {
            Camera.xCamera = 0;
        } else if (x > middleX && x < 2080) {
            Camera.xCamera = middleX;
        } else {
            Camera.xCamera = 2080 - middleX;
        }
    }

    private void updateYPos() {
        // Apply gravity when the player is in the air
        if (inAir) {
            //System.out.println("UPDATEY");
            airSpeed = gravity;

            // Check if the player can move vertically downward due to gravity
            System.err.println("Hitbox(" + hitBox.x + ", " + hitBox.y + ") " + x + " " + y + " CAMOFFSET " + Camera.getXOffset());
            if (CanMoveHere(hitBox.x, hitBox.y + airSpeed + 32, levelData)) {
                //System.out.println("FALLNOW");
                hitBox.y += airSpeed;
                y = hitBox.y;
                //resetInAir();
            } else {
                // If the player cannot move downward anymore due to collision with the ground
                //hitBox.y = GetEntityYPosUnderRoofFloor(hitBox, airSpeed);
                //y = hitBox.y;
                //System.err.println("REACHED GROUND");
                resetInAir();
                if(up) {
                    if (CanMoveHere(hitBox.x, hitBox.y + jumpSpeed - 32, levelData)) {
                        //System.out.println("JUMPNOW");
                        hitBox.y += 10 * jumpSpeed;
                        y = hitBox.y;
                        inAir = true;
                    }
                }
            }
        }
    }

    private void updatePos() {
        //System.err.println("Hitbox(" + hitBox.x + ", " + hitBox.y + ") " + x + " " + y + " CAMOFFSET " + Camera.getXOffset());
        moving = false;

        if (!inAir) {
            if (!IsEntityOnFloor(hitBox, levelData)) {
                //System.out.println("PLAYER IS NOT ON FLOOR.");
                inAir = true;
            }
        }

        // Check if the jump action is triggered
        if (up) {
            jump();
        }

        // Apply gravity when the player is in the air
        if (inAir) {
            updateYPos(); // Update vertical position including gravity
        }

        if (!left && !right && !up) {
            //System.err.println("NO MOVEMENT APPLIED");
            return;
        }

        float xSpeed = 0;

        if (speed)
            playerSpeed = 5.0f;
        else
            playerSpeed = 2.0f;

        if (left) {
            xSpeed -= playerSpeed;
        }

        if (right) {
            xSpeed += playerSpeed;
        }


        // Update horizontal position
        updateXPos(xSpeed);

        moving = true;
    }


    private void jump() {
        if (inAir) {
            System.err.println("Will not jump, player is in air.");
            return;
        }

        inAir = true;
        airSpeed = jumpSpeed;
        updateYPos();
    }

    private void resetInAir() {
        inAir = false;
        airSpeed = 0;
    }

    private void updateXPos(float xSpeed) {
        //System.err.println(CanMoveHere(hitBox.x + xSpeed, hitBox.y, hitBox.width, hitBox.height, levelData));
        // Calculate the middle position of the screen
        int middleX = 800 / 2 - 32; // Assuming a screen width of 800 pixels
        int hitboxDirectionOffset = 32;
        if(xSpeed < 0)
            hitboxDirectionOffset = 0;

        // If the player's x-coordinate is less than the middle position of the screen,
        // allow movement as usual
        if (hitBox.x < middleX - hitBox.width) {
           // System.err.println("LEFT BOUNDARY");
            if (CanMoveHere(hitBox.x + xSpeed + hitboxDirectionOffset, hitBox.y + 16, levelData)) {
                hitBox.x += xSpeed;
                x = hitBox.x;
            }
        }
        else if (hitBox.x < 2080 && hitBox.x > 2080 - middleX - hitBox.width) {
           // System.err.println("RIGHT BOUNDARY");
            if (CanMoveHere(hitBox.x + xSpeed + hitboxDirectionOffset, hitBox.y + 16, levelData)) {
                hitBox.x += xSpeed;
                x = hitBox.x;
            }
        } else {
            // System.err.println("MIDDLE MAP");
            // If the player's x-coordinate is greater than the middle position of the screen,
            // allow movement only if it doesn't cause the camera to exceed the right boundary of the level
            int rightBoundary = 2080 - 800; // Assuming a screen width of 800 pixels and level width 2080
            float deltaX = hitBox.x + xSpeed - hitBox.x;
            int cameraOffset = Camera.getXOffset();

            if(CanMoveHere(hitBox.x + xSpeed + hitboxDirectionOffset, hitBox.y + 16, levelData)) {
                if (cameraOffset + xSpeed <= rightBoundary) {
                Camera.update((int) deltaX); // Update the camera position based on the player's movement
                    // Calculate the distance the player will move
                }
                hitBox.x += deltaX;
                x = hitBox.x;
            }
        }
    }

    private boolean HasReachedLevelEnd() {
        if (x == 2080 - 32) {
            //displayCompletionDialog();
            return true;
        }
        return false;
    }

    private void displayCompletionDialog() {
        // Show a dialog box to get the player's name
        String playerName = JOptionPane.showInputDialog(null, "GAME COMPLETE!\n\nPlease enter your name:", "Game Won", JOptionPane.PLAIN_MESSAGE);

        if (playerName != null && !playerName.trim().isEmpty()) {
            // Handle the player name (e.g., save to the database, display on the screen, etc.)
            int time = Game.levelTimer.getTotalSeconds();
            System.out.println("Player name: " + playerName + " time: " + time);
            Game.leaderboardDbManager.insert(playerName, time);
        } else {
            System.out.println("No name entered.");
        }
    }


    private void setAnimation() {
        int startAnimation = playerAction;

        if (startAnimation != playerAction)
            resetAnimationTick();
    }

    public void initAnimations() {
        current_animation = player_right[IDLE];
    }

    private void resetAnimationTick() {
        aniIndex = aniTick = 0;
    }

    private void updateAnimation() {
        aniTick++;
        if (aniTick >= aniSpeed) {
            aniTick = 0;
            aniIndex++;
            if (aniIndex >= GetSpriteAmount(playerAction)) {
                aniIndex = 0;
            }
        }
    }

    public void loadLvlData() {
        this.levelData = map;

        if (!IsEntityOnFloor(hitBox, map))
            inAir = true;
    }

    public boolean isLeft() {
        return left;
    }

    public void setLeft(boolean left) {
        this.left = left;
    }

    public boolean isUp() {
        return up;
    }

    public void setUp(boolean up) {
        this.up = up;
    }

    public boolean isRight() {
        return right;
    }

    public void setRight(boolean right) {
        this.right = right;
    }

    public boolean isDown() {
        return down;
    }

    public void setDown(boolean down) {
        this.down = down;
    }

    public void resetDirBooleans() {
        up = down = left = right = false;
    }

    public void setSpeed(boolean speed) {
        this.speed = speed;
    }

    public void setJump(boolean jump) {
        this.jump = jump;
    }

    public void setHasTouchedGreenCannon() {hasTouchedGreenCannon = true;}
    public void setHasTouchedBrownCannon() {hasTouchedBrownCannon = true;}

    public int getCurrentLives() { return lives;}

    public void setLives(int lives) {
        this.lives = lives;
    }
}

