package entities;

import utils.Camera;

import java.awt.*;
import java.awt.geom.Rectangle2D;

//va fi folosita drept superclasa pt player si inamici
public abstract class Entity {
    protected float x,y;//protected->abstract
    protected int width, height;
    protected Rectangle2D.Float hitBox; // coliziuni
    public Entity(float x, float y, int width, int height)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }//consructor construire entitate

    protected void drawHitbox(Graphics g) {
        g.setColor(Color.WHITE);
        g.drawRect((int) (hitBox.x - Camera.getXOffset()), (int) hitBox.y, (int) hitBox.width, (int) hitBox.height);
    }


    protected void initHitbox(float x, float y, float width, float height) {
        hitBox = new Rectangle2D.Float(x,y,width,height);
    }

    public void updateHitbox() {
        hitBox.x = (int) x; //pentru cand se misca playerul
        hitBox.y = (int) y;
        /*x = (int) hitBox.x;
        y = (int) hitBox.y;*/
    }

    public Rectangle2D.Float getHitBox()
    {
        return hitBox;
    }
}

