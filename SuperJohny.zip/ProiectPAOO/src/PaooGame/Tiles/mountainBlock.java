package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

public class mountainBlock extends Tile
{
    /*! \fn public GrassTile(int id)
        \brief Constructorul de initializare al clasei

        \param id Id-ul dalei util in desenarea hartii.
     */
    public mountainBlock(int id)
    {
        /// Apel al constructorului clasei de baza
        super(Assets.mountainBlock, id);
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
