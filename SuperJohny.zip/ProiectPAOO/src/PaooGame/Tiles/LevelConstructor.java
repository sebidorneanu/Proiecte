package PaooGame.Tiles;

import PaooGame.Game;
import PaooGame.Graphics.ImageLoader;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;

import static PaooGame.Tiles.Tile.TILE_SIZE;
import static PaooGame.Tiles.Tile.tiles;
import static utils.Camera.xCamera;

public class LevelConstructor {
    private static BufferedImage img = ImageLoader.LoadImage("/textures/background.jpg");
    public static int map[][] = new int[40][130];

    private int currentLevel;

    public LevelConstructor() {
        LevelSelector(1);
    }
    public void LevelSelector(int id) {
        currentLevel = id;
        switch(id) {
            case 1: img = ImageLoader.LoadImage("/textures/background.jpg");
            break;
            case 2: img = ImageLoader.LoadImage("/textures/nivel2background.jpeg");
            break;
            case 3: img = ImageLoader.LoadImage("/textures/nivel2background.jpeg"); //inlocuieste cu background
                // pt nivelul 3
                break;
            default: break;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader("nivel" + id + ".csv"));
            int j = 0;
            String line;
            while ((line = br.readLine()) != null) {
                System.err.println(line);
                String[] values = line.split(",");
                for (int i = 0; i < 130; i++) {
                    map[j][i] = Integer.parseInt(values[i]);
                }
                j++;
            }
        } catch (Exception e) {e.printStackTrace();}
    }


    private void LevelBuilder()
    {

    }

    public void selectLevel(int levelID) {
        if(levelID > 0 && levelID <= 3)
            LevelSelector(levelID);
    }

    public void draw(Graphics g)
    {
        g.drawImage(img,0,0,null);
        //LevelConstructor();
        for(int i = 0; i<15;i++)
            for(int j = 0; j<130;j++)
            {
                if(map[i][j] >= 0)//cu -1 nu avem nimic reprezentat
                    if(tiles[map[i][j]] != null)
                        tiles[map[i][j]].Draw(g,16*j-xCamera,16*i);
            }
    }

    public int[][] getData()
    {
        return map;
    }

    public int getCurrentLevel() { return currentLevel; }
}