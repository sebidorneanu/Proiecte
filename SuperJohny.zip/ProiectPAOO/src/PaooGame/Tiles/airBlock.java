package PaooGame.Tiles;

import PaooGame.Graphics.Assets;
public class airBlock extends Tile {

    public airBlock(int id)
    {

        super(Assets.airBlock,id);
    }

    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
