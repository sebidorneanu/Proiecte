package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

public class questionBlock extends Tile{
    public questionBlock(int id)
    {
        /// Apel al constructorului clasei de baza
        super(Assets.questionBlock, id);
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
