package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

 public class lower_pipe_left extends Tile
{

    public lower_pipe_left(int id)
    {
        super(Assets.lower_pipe_left, id);
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
