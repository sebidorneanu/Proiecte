package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

public class lower_pipe_right extends Tile
{

    public lower_pipe_right(int id)
    {
        super(Assets.lower_pipe_right, id);
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }
}
