package PaooGame.Tiles;

import PaooGame.Graphics.Assets;
public class flagTile extends Tile {

    public flagTile(int id)
    {

        super(Assets.flagTile,id);
    }
}
