package PaooGame.Tiles;

import PaooGame.Graphics.Assets;

public class upper_pipe_left extends Tile
{
    public upper_pipe_left(int id)
    {
        super(Assets.upper_pipe_left, id);
    }
    @Override
    public boolean IsSolid()
    {
        return true;
    }

}
