package PaooGame.Graphics;

import java.awt.image.BufferedImage;


/*! \class public class Assets
    \brief Clasa incarca fiecare element grafic necesar jocului.

    Game assets include tot ce este folosit intr-un joc: imagini, sunete, harti etc.
 */
public class Assets
{
    public static BufferedImage[][] player_left;//matrice de animatii stanga personaj principal
    public static BufferedImage[][] player_right;

    public static BufferedImage groundBlock;
    public static BufferedImage airBlock;

    public static BufferedImage questionBlock;

    public static BufferedImage   upper_pipe_left;
    public static BufferedImage   upper_pipe_right;

    public static BufferedImage   lower_pipe_left;
    public static BufferedImage   lower_pipe_right;
    public static BufferedImage mountainBlock;
    public static BufferedImage flagTile;

    public static BufferedImage brownCannon;
    public static BufferedImage greenCannon;



    /*! \fn public static void Init()
        \brief Functia initializaza referintele catre elementele grafice utilizate.

        Aceasta functie poate fi rescrisa astfel incat elementele grafice incarcate/utilizate
        sa fie parametrizate. Din acest motiv referintele nu sunt finale.
     */
    public static void Init()
    {
            /// Se creaza temporar un obiect SpriteSheet initializat prin intermediul clasei ImageLoader
        //separ imaginea in sprite uri de 16x16
        SpriteSheet sheet = new SpriteSheet(ImageLoader.LoadImage("/textures/blocks.png"),16,16);

            /// Se obtin subimaginile corespunzatoare elementelor necesare.

        groundBlock = sheet.crop(0, 0);
        airBlock=sheet.crop(1,0);
        upper_pipe_left=sheet.crop(0,9);
        upper_pipe_right=sheet.crop(1,9);
        lower_pipe_left=sheet.crop(0,10);
        lower_pipe_right=sheet.crop(1,10);
        questionBlock=sheet.crop(27, 0);
        mountainBlock=sheet.crop(0, 1);
        flagTile=sheet.crop(5, 7);
        brownCannon=sheet.crop(10,1);
        greenCannon=sheet.crop(10, 8);

        /*for(int i  = 0; i < 9; i++)
        {
            for(int j = 0; j < 13; j++)
            {
                int index = i*13 + j;

                if(tiles[index] == null)
                {
                    tiles[index] = new Tile(sheet.crop(j, i), index);
                }
            }
        }

         */
        player_right = new BufferedImage[6][6];
        player_left = new BufferedImage[6][6];

        SpriteSheet rightAnimations = new SpriteSheet(ImageLoader.LoadImage("/textures/RightAnimations.png"),55,55);

        for(int i = 0; i <6; i++)
        {

                player_right[0][i] = rightAnimations.crop(i,0);
            //vector de subimagini
        }

        SpriteSheet leftAnimations = new SpriteSheet(ImageLoader.LoadImage("/textures/LeftAnimations.png"),55,55);

        for(int i = 5; i>=0; --i)
        {

            player_left[0][5-i] = leftAnimations.crop(i,0);
            //vector de subimagini
        }

    }
}
