package PaooGame;// aceasta clasa va fi folosita exclusiv in thread-ul de run.

import java.awt.*;

public class LevelTimer {
    private static int hours;
    private static int minutes;
    private static int seconds;
    private static int frames;
    private static long oldTimens;
    private static long newTimens;
    public LevelTimer() {
        oldTimens = System.nanoTime();
        hours = 0;
        minutes = 0;
        seconds = 0;
        frames = 0;
    }

    public static void updateTimer() {
        newTimens = System.nanoTime();

        if((newTimens - oldTimens) > 1000000000 / 60) {
            ++frames;
            if(frames >= 45) { //constanta, aparent numara bine?
                ++seconds;
                if (seconds > 59) {
                    ++minutes;
                    if (minutes > 59) {
                        ++hours;
                        minutes = 0;
                    }
                    seconds = 0;
                }
                frames = 0;
            }
            oldTimens = newTimens;
        }
    }

    public void resetTimer()  {
        oldTimens = System.nanoTime();
        frames = 0;
        hours = 0;
        minutes = 0;
        seconds = 0;
    }

    public int getTotalSeconds() {
        return hours * 3600 + minutes * 60 + seconds;
    }

    public static void drawTimer(Graphics g) {
        g.setColor(Color.BLACK);
        g.drawString("Time: " + hours + ":" + minutes + ":" + seconds,  340, 20);
    }

    public void setTimeInSeconds(int time) {
        seconds = time;
        minutes = seconds / 60;
        seconds %= 60;
        hours = minutes / 60;
        minutes %= 60;
    }
}
