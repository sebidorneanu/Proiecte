package PaooGame;

import PaooGame.GameWindow.GameWindow;
import utils.Camera;

import javax.swing.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import static utils.Constants.Directions.*;

public class KeyboardInput implements KeyListener {

    private Game gamepanel;
    public KeyboardInput(Game gamepanel) {
        this.gamepanel = gamepanel;
    }



    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode())
        {
            case KeyEvent.VK_W:
                gamepanel.getPlayer().setUp(true);
                break;
            case KeyEvent.VK_A:
                gamepanel.getPlayer().setLeft(true);
                Camera.moveLeft = true;
                break;
            case KeyEvent.VK_S:
                gamepanel.getPlayer().setDown(true);
                break;
            case KeyEvent.VK_D:
                gamepanel.getPlayer().setRight(true);
                Camera.moveRight = true;
                break;
            case KeyEvent.VK_SHIFT:
                gamepanel.getPlayer().setSpeed(true);
                break;
            case KeyEvent.VK_SPACE:
                gamepanel.getPlayer().setJump(true);
                break;
            case KeyEvent.VK_F1:
                gamepanel.getSaveGameDBManager().saveGame(
                        gamepanel.getPlayer().getHitBox().x,
                        gamepanel.getPlayer().getHitBox().y,
                        gamepanel.getPlayer().getCurrentLives(),
                        gamepanel.levelTimer.getTotalSeconds(),
                        gamepanel.levelManager.getCurrentLevel()
                );
                break;
            case KeyEvent.VK_F2:
                String input = JOptionPane.showInputDialog(null, "LOAD GAME\n\nPlease enter savegame ID:", "LOAD GAME", JOptionPane.PLAIN_MESSAGE);

                if (input != null && !input.trim().isEmpty()) {
                    int saveID = Integer.parseInt(input);
                    gamepanel.getSaveGameDBManager().loadGame(saveID);
                } else {
                    System.out.println("No savegame ID entered.");
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        switch (e.getKeyCode())
        {
            case KeyEvent.VK_W:
                gamepanel.getPlayer().setUp(false);
                break;
            case KeyEvent.VK_A:
                Camera.moveLeft = false;
                gamepanel.getPlayer().setLeft(false);
                break;
            case KeyEvent.VK_S:
                gamepanel.getPlayer().setDown(false);
                break;
            case KeyEvent.VK_D:
                Camera.moveRight = false;
                gamepanel.getPlayer().setRight(false);
                break;
            case KeyEvent.VK_SHIFT:
                gamepanel.getPlayer().setSpeed(false);
                break;
            case KeyEvent.VK_SPACE:
                gamepanel.getPlayer().setJump(false);
                break;
            default:
                break;
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }


}