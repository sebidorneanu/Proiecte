import numpy as np
from scipy.io import wavfile

# Citește fișierul .wav de pe Desktop
samplerate, data = wavfile.read(r'C:\Users\EDU\Downloads\11.wav')

# Scrie informații despre fișierul wav într-un fișier text
wavFileInfo = open("waveInfo11.txt", "a")
wavFileInfo.write(str(samplerate) + '\n')
wavFileInfo.write(str(data.size) + '\n')
wavFileInfo.close()

# Afișează rata de eșantionare și dimensiunea datelor
print(samplerate)
print(data.size)
print(data)

# Salvează datele audio într-un fișier text
np.savetxt("waveData11.txt", data, fmt="%2.0f")
